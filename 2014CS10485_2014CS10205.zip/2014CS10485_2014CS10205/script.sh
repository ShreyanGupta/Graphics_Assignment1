make
./render inputs/input2.txt
./DisplayImage matrix.txt